temperatures = [28, 32, 35, 31, 29, 30, 33, 36, 27, 25, 34, 30, 29, 37, 38, 26, 31, 35, 33, 32, 36, 34, 29, 28, 27, 35, 32, 30, 31, 33]

above_32 = [temp for temp in temperatures if temp > 32]

print(above_32)
